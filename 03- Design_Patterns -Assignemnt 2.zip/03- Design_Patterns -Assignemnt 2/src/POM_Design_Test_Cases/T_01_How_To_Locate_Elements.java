//Creating Automation TCs by using POM Design Pattern [ Also using Constructors concept]
package POM_Design_Test_Cases;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import POM_DEsign_Pages.Home_Page;
import POM_DEsign_Pages.SignIn_Page;

public class T_01_How_To_Locate_Elements {

	static WebDriver driver;

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		Launch_Browser();

		Login_With_Invalid_Email();
	
		Verify_Forgot_Email_URL();
		
		Google_Search();

		Close_Driver();
		
	}


//Before Test
public static void Launch_Browser()
{
	
	String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
	System.setProperty("webdriver.chrome.driver", chromePath);
	driver = new ChromeDriver();

	driver.manage().window().maximize();
	driver.navigate().to("https://www.google.com/?hl=ar");

	driver.findElement(By.partialLinkText("Eng")).click();
}


//Test Case 1: Login without using email
public static void Login_With_Invalid_Email() throws InterruptedException
{
//	Home_Page home = new Home_Page(); 
//	home.SignInBtn(driver).click();
//	
//	SignIn_Page sign = new SignIn_Page(); 
//	sign.EmailField(driver).sendKeys("");
//	sign.NextBtn(driver).click();
//	Thread.sleep(2000);
//	String actualResult;
//	actualResult =sign.error_msg(driver).getText();
//
//	System.out.println(actualResult);
//	System.out.println(actualResult.contains("Couldn't find your Google Account"));

//1-Sign-In Button::: 
//After Creating separate Class & Method for the element locator [Home_Page Class] ,  
//we need to Call the element locators from the "Home_Page" Class	
//so 1st create Object to make call to "Home_Page" Class	
	Home_Page home = new Home_Page(driver); //Create object with name [ home] to call the Class & add the (driver) that will use it from the Constructor 

//then from this object make calling to the element -"SignInBtn" method- then the action
//But No need to make call for the (driver) too with every method as i've already created driver contractor in the class & updated the above object with (driver) 	
	home.SignInBtn().click();
//===========
	
//2-Enter Email in Sign-In Page::: 
//After Creating separate Class & Method for the element locator [SignIn_Page Class ] ,  
//we need to Call the element locators from the "SignIn_Page" Class	
//so 1st create Object to make call to "SignIn_Page" Class	
	SignIn_Page sign = new SignIn_Page(driver); //Create object with name [sign] to call the Class & add the (driver) that will use it from the Constructor 

//then from previous object make calling to the element -the "EmailField" method- then the action, in order to enter email
//But No need to make call too for the (driver) with every method as i've already created driver contractor in the class & updated the above object with (driver) 	
	sign.EmailField().sendKeys(""); //Make it empty mail
//===========	
//3-Click Next button::: 
//Already Next button here exist in Sign-in page so no need to create new Class but create new method
//Also no need to create new object as the previous object call the same Class
	//So from the above object make calling to the element -the "NextBtn" method- then the action, in order to enter email
	//But No need to make call too for the (driver) with every method as i've already created driver contractor in the class & updated the above object with (driver)
	sign.NextBtn().click();

	
	//Create thread exception in order to make waiting 2 seconds before executing the next step
	Thread.sleep(2000);

//4-Actual Result::: 
	//Already "Error Message" here exist in Sign-in page so no need to create new Class but create new method in "SignIn_Page" Class
	//Also no need to create new object as the previous object call the same Class
	//So from the above object make calling to the element -the "error_msg" method- then the action, in order to enter email
	   //but 1st create string variable for actual result
	String actualResult;
	actualResult =sign.error_msg().getText();//But No need to make call for the (driver) with every method as i've already created driver contractor in the class & updated the above object with (driver)

	System.out.println(actualResult);
	System.out.println(actualResult.contains("Enter an email or phone number"));
	//Enter an email or phone number
	//Couldn't find your Google Account
}

//Test Case 2: Get forget email URL (Just forgot email button & get it's URL)  [ Also using Constructors concept ]
public static void Verify_Forgot_Email_URL()
{

//	driver.findElement(By.xpath("//button[@jsname=\"Cuz2Ue\"]")).click();
//	String actualResult;
//	actualResult = driver.getCurrentUrl();
//	System.out.println(actualResult);
//	System.out.println(actualResult.contains("/signin/v2/usernamerecovery"));

	
	SignIn_Page sign = new SignIn_Page(driver);
	sign.forgot_email().click();
	
	String actualResult;
	actualResult = driver.getCurrentUrl();
	
	System.out.println(actualResult);
	System.out.println(actualResult.contains("/signin/v2/usernamerecovery?"));
	//==/signin/v2/usernamerecovery? ... this the correct URL
   //==/signin/v2/forgotemail..this the wrong URL
	
}

//Test Case 3: Google Search [ Also using Constructors concept]
public static void Google_Search() {
	driver.navigate().to("https://www.google.com/?hl=ar");
	driver.findElement(By.partialLinkText("Eng")).click();

//	driver.findElement(By.name("q")).click();
//	driver.findElement(By.name("q")).sendKeys("selenium");
//	driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
	
	Home_Page home = new Home_Page(driver);
	home.SearchField().click();
	home.SearchField().sendKeys("selenium");
	home.SearchField().sendKeys(Keys.ENTER);
	
	//Searching on "Selenium" Result counts & result [ Ex :About 48,000,000 results (0.60 seconds)]
	System.out.println(driver.findElement(By.id("result-stats")).getText());
	System.out.println(driver.findElement(By.id("result-stats")).getText().contains("48,000,000"));

}


//After Test
public static void Close_Driver()
{
 driver.quit();

}
}
