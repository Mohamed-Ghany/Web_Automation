//Test Cases Class for Login with Valid & Invalid Username/Password on "http://the-internet.herokuapp.com/login"

package Test_Cases;

import org.testng.annotations.Test;

import Pages.P_01_Login_Page;

import org.testng.annotations.BeforeTest;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertThrows;
import static org.testng.Assert.assertTrue;

import java.awt.RenderingHints.Key;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
public class T_01_Login_Test_Case extends T_00_TestBase {
 	

//==========  
  
  @Test //[TC#1 for Invalid username
  public void Invalid_Username() {
	  //Create new Object :
	  P_01_Login_Page p01 = new P_01_Login_Page(driver);
	  
	  //1-Enter Invalid username
	  p01.username_txt().sendKeys("username");
	  
	  //2-Enter Invalid Password
	  p01.username_txt().sendKeys("password");
	  
	  //3-Click action on Login button
	  p01.FLogin_Btn().click();
	  System.out.println(p01.flash_message().getText());
	  	  
	  //4-assertion error message
	  assertTrue(p01.flash_message().getText().contains("Your username is invalid"));
  		  
  	  } 
//==========
  @Test //[TC#2 Login with Valid username ]
      
  public void Valid_Username() throws InterruptedException {
	  //Create new Object :
	  P_01_Login_Page p01 = new P_01_Login_Page(driver);
	  
	  //1-Clear Username Field
	  p01.username_txt().clear();
	  
	  //2-Enter valid username
	  p01.username_txt().sendKeys("tomsmith");
	  
	  //3-Clear Password Field
	  p01.password_txt().clear();
	  
	  //4-Enter valid Password
	  p01.password_txt().sendKeys("SuperSecretPassword!");
	  
	  //5-Press Submit
	  p01.password_txt().submit();
	  System.out.println(p01.flash_message().getText());
	  
	  //6-Verify success Message :
	  assertTrue(p01.flash_message().getText().contains("You logged into a secure area"));
  	  
  	  } 

  @AfterTest
  public void afterTest() {
	  
	  //driver.quit();  
  }

}
//Make inheritance from "TestBase" Class


