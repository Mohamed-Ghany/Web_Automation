package Test_Cases;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

public class T_00_TestBase {

//1-Data Field Declaration  :
	  WebDriver driver;
	  //String browserName = "chrome"; //create new variable to control the browser [ but no need to it after adding this variable in "Properties file" & create the below method ]
	  
//2-Create method -& name it "getProperty"-to call the values from "Properties file "
	  public String getProperty(String keyName) throws IOException  // Also create String variable and name it KeyName,so that every time add the keyname of the variable you want to call from "Properties File"  
	  {
		//1-create new object from "Properties class"
		  Properties prop = new Properties();
		
		//2-create another new object from "property class" & add file name and path	  
		  FileInputStream fis = new FileInputStream(System.getProperty("user.dir") +"\\data.properties");
		  
	   //3-make Load to the file input stream 
		  prop.load(fis);
		  
	  //4-get the values by using the "Keyname" variable
		return  prop.getProperty(keyName);
		  
	}
	  
  @BeforeTest
  public void beforeTest() throws IOException  
  {     //3-make calling to getProperty Method to get the variable "browserName" values which is "chrome" from [ Properties file]
	  if(getProperty("browserName").equals("chrome"))
	  {
	  String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", chromePath);
		driver = new ChromeDriver(); //Create New object from chrome Driver
	  }
	  else if (getProperty("browserName").equals("firefox"))
	  {		  
		  String firefoxPath = System.getProperty("user.dir") + "\\Drivers\\geckodriver.exe";
			System.setProperty("webdriver.gecko.driver", firefoxPath);
			driver = new FirefoxDriver(); //Create New object from firefox Driver   
	  }
		driver.manage().window().maximize();
		driver.navigate().to("http://the-internet.herokuapp.com/login"); //Login page in new project

//Then to avoid time out-[its difference from project & another ]-i want to  :
//inform system to make "refresh" after every TC [by using annotation @AfterMethd]  ,
//then to wait around 2 seconds before executing the next TC [ by using implicit ] in annotation @Before test]
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
  }
 
 // 
 @AfterMethod
 
 public void afterMethod () {
	 driver.navigate().refresh(); //Make refresh after every TC
 }

  @AfterTest
  public void afterTest() {
	  
	driver.quit();
  }

}

//=======This before "File Properties"

////Data Field :
//WebDriver driver;
//
//@BeforeTest
//public void beforeTest() 
//{
//String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
//	System.setProperty("webdriver.chrome.driver", chromePath);
//	driver = new ChromeDriver(); //Create New object from chrome Driver
//
//	driver.manage().window().maximize();
//	driver.navigate().to("http://the-internet.herokuapp.com/login"); //Login page in new project
//}
//
//@AfterTest
//public void afterTest() {
//
//driver.quit();
//}
//
//}