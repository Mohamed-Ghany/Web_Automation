//This Class for elements
package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;

public class P_01_Login_Page extends P_00_PageBase { // Make inheriting from "P_00_PageBase" class "

	//Delete below WebDriver driver; & Constructor after copy & pasting then in "P_00_PageBase" class 
//	WebDriver driver;
//	
//	public P_01_Login_Page(WebDriver driver) 
//	{
//		this.driver = driver; 		
//	}

//Create below Constructor that will Yenaffez el constructor elle fel "P_00_PageBase" class elle 3amel inheritance mennoh 	
	public P_01_Login_Page(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}	
	
//create Methods for elements :
	
//Methods Related to Enter Valid/Invalid Username & password on # http://the-internet.herokuapp.com/login [ T_01_Login_Test_Case] Class 
//by using PageFactory:
//1-use @FindBy Annotation + Locating element 	
@FindBy (id = "username")	
//2-Make Declaration to WebElement 
WebElement UserName;

@FindBy (id = "password")	
WebElement Password;

//3-Create the Method
	public WebElement username_txt ()
	{
//	   return driver.findElement(By.id("username"));	
		return UserName;
	}	


	public WebElement password_txt ()
	{
	   //return driver.findElement(By.id("password"));	
		return Password;
	}	
	
//========	
	public WebElement flash_message() 
	{
		return driver.findElement(By.id("flash"));
	}
	
//==========	
//Method -Related to TC# 1 - for Element of "Elemntal_Selenuim" that exit in the page	

		public WebElement Elemntal_Selenuim() {
			
			return driver.findElement(By.xpath("//a[@target=\"_blank\"]"));		
		}
		
//Method -Related to TC# 2 -for Element of Login button
		
				public WebElement FLogin_Btn() {
					
					return driver.findElement(By.cssSelector("button[type=\"submit\"]"));		
				}
		
//Method -Related to TC# 2 -for Element of Error " Your username is invalid!" background color "Red"
		
			public WebElement Flash_Error() {
				
				return driver.findElement(By.id("flash"));		
			}
}
