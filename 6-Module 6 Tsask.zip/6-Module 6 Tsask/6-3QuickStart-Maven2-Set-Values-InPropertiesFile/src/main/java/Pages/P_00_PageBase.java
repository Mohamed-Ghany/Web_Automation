package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class P_00_PageBase {

//Create Data Field : So Create New driver variable which will take the value from the  main driver that added also in the below constructor
	
	WebDriver driver;
	
//Create constructor that will contain the Driver that i'll use in Execution
//          public P_00_PageBase(WebDriver driver) // the driver her is the main driver
//    {
//		
//        this.driver = driver; //first driver is the new variable created in Data field , second driver is the main driver 	  
//	}
		
	
//Create constructor - by PageFactory Class-  that will contain the Driver that i'll use in Execution
  public P_00_PageBase(WebDriver driver) // the driver her is the main driver
{

this.driver = driver; //first driver is the new variable created in Data field , second driver is the main driver 

PageFactory.initElements(driver, this); //PageFactory Class & initElements(null,driver) Methods are exist in Selenuim Framework

}

	
	
}
